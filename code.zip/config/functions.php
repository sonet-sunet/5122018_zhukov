<?php
function d($ar){
    echo "<pre>";
    print_r( $ar );
    echo "</pre>";
}