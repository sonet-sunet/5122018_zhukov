    </div>
    <?php foreach( $pageConfig['jsFiles'] as $path_js): ?>
        <script src="<?=$path_js?>"></script>
    <?php endforeach; ?>
</body>
</html> 